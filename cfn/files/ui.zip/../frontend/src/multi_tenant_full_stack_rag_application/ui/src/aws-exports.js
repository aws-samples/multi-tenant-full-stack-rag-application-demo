/* eslint-disable */

const awsmobile = {
    "app_name": 'Multi-tenant full-stack RAG application demo',
    "ingestion_bucket_name": 'mtfsradbtestingestionprovi-ingestionbucket4cba59aa-3mf91ofygoe6',
    "aws_project_region": 'us-west-2',
    "aws_cognito_identity_pool_id": 'us-west-2:534b4526-c02e-493d-b064-52aea1bc7c85',
    "aws_cognito_region": 'us-west-2',
    "aws_user_pools_id": 'us-west-2_J2Sa6E6Cl',
    "aws_user_pools_web_client_id": '44qpjb30d5u44r2dll0seoq7g4',
    "oauth": {},
    "aws_cognito_username_attributes": [],
    "aws_cognito_social_providers": [],
    "aws_cognito_signup_attributes": [
        "EMAIL"
    ],
    "aws_cognito_mfa_configuration": "OFF",
    "aws_cognito_mfa_types": [
        "SMS"
    ],
    "aws_cognito_password_protection_settings": {
        "passwordPolicyMinLength": 8,
        "passwordPolicyCharacters": []
    },
    "aws_cognito_verification_mechanisms": [
        "EMAIL"
    ],
    "enabled_enrichment_pipelines": {"entity_extraction": {"name": "Entity Extraction"}},
    "api_urls": {
        "document_collections":  'https://l90q2m4pe2.execute-api.us-west-2.amazonaws.com',
        "generation": 'https://pumjm0rdyd.execute-api.us-west-2.amazonaws.com',
        /* "initialization": '',*/ 
        "prompt_templates": 'https://1b3sqdlgr9.execute-api.us-west-2.amazonaws.com',
        "sharing": '<SHARING_HANDLER_API_URL>'
    }
};


export default awsmobile;
