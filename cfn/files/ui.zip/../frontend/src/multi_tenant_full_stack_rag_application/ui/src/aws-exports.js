/* eslint-disable */

const awsmobile = {
    "app_name": 'Multi-tenant full-stack RAG application demo',
    "ingestion_bucket_name": 'mtfsradbdevingestionprovid-ingestionbucket4cba59aa-3ky6aewrbxd7',
    "aws_project_region": 'us-west-2',
    "aws_cognito_identity_pool_id": 'us-west-2:2735d64e-ab0c-4513-bae5-76a50f53e34e',
    "aws_cognito_region": 'us-west-2',
    "aws_user_pools_id": 'us-west-2_0AoflWe6M',
    "aws_user_pools_web_client_id": '1svpom5c415nk3m249mn3397g0',
    "oauth": {},
    "aws_cognito_username_attributes": [],
    "aws_cognito_social_providers": [],
    "aws_cognito_signup_attributes": [
        "EMAIL"
    ],
    "aws_cognito_mfa_configuration": "OFF",
    "aws_cognito_mfa_types": [
        "SMS"
    ],
    "aws_cognito_password_protection_settings": {
        "passwordPolicyMinLength": 8,
        "passwordPolicyCharacters": []
    },
    "aws_cognito_verification_mechanisms": [
        "EMAIL"
    ],
    "enabled_enrichment_pipelines": {"entity_extraction": {"name": "Entity Extraction"}},
    "api_urls": {
        "document_collections":  'https://i537uyvid5.execute-api.us-west-2.amazonaws.com',
        "generation": 'https://r8uaiez5qa.execute-api.us-west-2.amazonaws.com',
        /* "initialization": '',*/ 
        "prompt_templates": 'https://mlad8yib15.execute-api.us-west-2.amazonaws.com',
        "sharing": '<SHARING_HANDLER_API_URL>'
    }
};


export default awsmobile;
