import pubmed_xml
import os
import sys
from lxml import etree

pubmed = pubmed_xml.Pubmed_XML_Parser()

for article in pubmed.parse('39195676'):
    print(article)
    print(f"\n\n{article.data}")

# print(os.getcwd())

# articles_dir = '../crawlers.PRIVATE/output'

# os.makedirs('../crawlers.PRIVATE/output', exist_ok=True)

# with open('../crawlers.PRIVATE/input/tmp.xml', 'r') as f_in:
#     lines = f_in.readlines()
#     curr_article = ''
#     delim_start = '<PubmedArticle>'
#     delim_end = '</PubmedArticle>'
#     for line in lines:
#         if line.startswith('<?xml version') or \
#             line.startswith('<!DOCTYPE PubmedArticleSet') or \
#             line.startswith('<PubmedArticleSet') or \
#             line.startswith('</PubmedArticleSet'):
#             continue

#         if delim_end in line or delim_start in line:
#             parts = line.split(delim_end)
#             # print(f"Got line parts {parts}")
#             print(f"Length of line: {len(line)}")
#             print(f"Number of parts {len(parts)}")
#             for part in parts:
#                 curr_article = ''
#                 if delim_start in part:
#                     # there's a whole article here.
#                     if not part.startswith(delim_start):
#                         # there's something unexpected here, so throw
#                         # away the stuff between the previous 
#                         # delim_end, which we just split on above,
#                         # and the current delim_start
#                         part = delim_start + parts.split(delim_start, 1)[1] + delim_end
#                     else:
#                         part = part + delim_end
#                     # now there should only be one article in the part. Write it
#                     # to output by the PMID number.
#                     pmid = part.split('</PMID>')[0].split('<PMID Version="1">')[1]
#                     print(f"Got pmid {pmid}")
#                     output_path = '../crawlers.PRIVATE/output'
#                     with open(f'{output_path}/{pmid}.xml', 'w') as f_out:
#                         f_out.write(part)
                    
#                     sys.exit()
#                 else:
#                     # there's the end of an article here
#                     # but no beginning in this line.
#                     pass
#             sys.exit()
#         else:
#             raise Exception(f"There was no start ({delim_start}) or end ({delim_end}) delimiter in this line. {line}")

# # path_xml = pp.list_xml_path('../crawlers.PRIVATE/input') # list all xml paths under directory
# # print(f"path_xml = {path_xml}")
# # pubmed_dict = pp.parse_pubmed_xml(path_xml[0]) # dictionary output
# # print(pubmed_dict)