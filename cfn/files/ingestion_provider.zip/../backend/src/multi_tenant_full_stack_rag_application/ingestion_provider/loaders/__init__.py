#  Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
#  SPDX-License-Identifier: MIT-0

from .loader import Loader
# from .docx_loader  import DocxLoader
from .pdf_image_loader import PdfImageLoader
# from .pdf_text_loader import PdfTextLoader
# from .text_loader import TextLoader
# from .xlsx_loader import XlsxLoader
